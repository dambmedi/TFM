# Pipeline técnico — Detalle por fase

> Este documento traduce el plan técnico y el contexto del TFM (`contexto-aplicacion-ia-triaje.md`, ya generado en sesiones previas) en decisiones concretas de implementación. Consúltalo antes de escribir cualquier notebook o script.

## Fase 1 — Ingesta y EDA (`01-data-ingest-and-eda.ipynb`)

**Fuentes a cargar:**
- MIMIC-IV-ED v2.2 (requiere credencial CITI/PhysioNet del integrante que la tenga).
- "Clasificación en Triaje Urgencias" — datos.gov.co (Min. Salud).
- BDUA (ADRES) — variables demográficas, régimen de afiliación.
- Datos abiertos Supersalud — desempeño operativo EPS/IPS (uso secundario, probablemente no como feature directa del modelo sino como contexto).

**Qué debe producir el EDA:**
- Conteo real de registros por nivel de triaje (I-V) — esto resuelve la brecha "tamaño real del dataset por clase" que quedó como desconocida en el requisito cerrado. Repórtalo explícitamente, no lo asumas.
- Distribución de valores nulos por variable.
- Verificación de si el desbalance esperado (mayoría en IV-V) se confirma con los datos reales.
- Esquema unificado de columnas entre MIMIC-IV-ED y las fuentes colombianas (los nombres de campos casi seguro no coinciden — este es el primer punto real de fricción técnica del proyecto).

## Fase 2 — Preprocesamiento (`02-preprocessing.ipynb`, `src/preprocess.py`)

**Variables estructuradas prioritarias** (por peso predictivo reportado en la literatura citada en el TFM — Lee et al. 2022, Casteñeda-Lopera et al. 2024):
- Saturación de oxígeno (SpO₂)
- Frecuencia respiratoria
- Temperatura corporal
- Presión arterial sistólica (y diastólica si disponible)
- Frecuencia cardíaca
- Edad
- Vía de llegada (ambulancia / particular / remisión)
- Escala de dolor (0-10)

**Transformaciones:**
- Imputación estadística para nulos (mediana para numéricas sesgadas, moda para categóricas; documentar la técnica elegida por variable, no aplicar una regla ciega global).
- Normalización de numéricas (StandardScaler o MinMax según la sensibilidad del modelo aguas abajo — XGBoost no la necesita estrictamente, pero sí la necesitan modelos lineales y redes).
- One-hot encoding de categóricas de baja cardinalidad; considerar target/frequency encoding si alguna categórica tiene alta cardinalidad (ej. código de motivo de consulta).
- Splits: mantener estratificación por nivel de triaje al hacer train/test split, dado el desbalance de clases — un split aleatorio simple puede dejar casi sin ejemplos de Nivel I en test.

**Texto libre (notas de admisión):**
- Limpieza básica (normalización de acentos/mayúsculas, pero sin eliminar términos clínicos).
- Tokenización vía el tokenizer del modelo de embeddings elegido (no un tokenizer genérico separado).

## Fase 3 — Modelos baseline (`03-baseline-models.ipynb`)

- Entrenar Regresión Logística, Random Forest y XGBoost **solo sobre datos estructurados** (sin texto) — esta es la línea base de comparación obligatoria para poder argumentar en el Cap. 5 que el enfoque multimodal aporta valor real.
- Aplicar `class_weight='balanced'` o técnicas de `imbalanced-learn` (SMOTE) como tratamiento del desbalance — probar con y sin, y reportar el efecto en el recall de Nivel I/II específicamente, no solo en el score agregado.
- Reportar desde esta fase el desglose de métricas por clase (no esperar a la Fase 5 para hacerlo por primera vez) — así se detecta temprano si el problema es viable con el criterio de aceptación fijado.

## Fase 4 — Modelo multimodal (`04-multimodal-training.ipynb`, `src/embeddings.py`)

**Dos arquitecturas a implementar y comparar (no elegir una a priori):**

- **Fusión temprana (early fusion):** concatenar el vector de features estructuradas normalizadas con el embedding del texto libre en un único vector, y entrenar un solo clasificador (XGBoost sobre el vector combinado, o una red densa simple).
- **Fusión tardía (late fusion):** dos submodelos independientes —
  - Submodelo A (estructurado): el mejor baseline de la Fase 3.
  - Submodelo B (texto): embedding + clasificador simple (regresión logística o cabeza densa sobre el embedding).
  - Combinación: promedio ponderado de probabilidades, o un meta-clasificador (stacking) entrenado sobre las salidas de A y B.

**Embeddings de texto:** usar `sentence-transformers` con un modelo clínico en español si está disponible; si no, documentar explícitamente que se usa un modelo genérico como limitación (esto es exactamente el tipo de limitación que el Cap. 6 del TFM debe declarar).

**Justificación a documentar:** cuál arquitectura gana y por qué, con métricas concretas — el Cap. 4 necesita esta justificación, no solo el resultado final.

## Fase 5 — Evaluación y explicabilidad (`05-evaluation-and-shap.ipynb`)

**Métricas obligatorias (no opcionales):**
- Matriz de confusión (5x5, niveles I-V).
- Precisión, recall, F1 — **por clase y macro**.
- AUC-ROC y AUPRC — la literatura citada en el TFM (Ueareekul et al. 2024) usa ambas porque AUROC solo puede ser engañoso en clases minoritarias como Nivel I.
- Validación cruzada de 10 pliegues (10-fold), estratificada por nivel.
- Comparación explícita contra los benchmarks ya citados en el estado del arte del TFM: CTAS (AUROC 0.882), Raita et al. 2019 (AUC-ROC 0.87), Ueareekul et al. 2024 (AUROC 0.917, AUPRC 0.629).

**SHAP:**
- Calcular SHAP sobre el modelo ganador (early o late fusion, el que gane en la Fase 4).
- Producir el ranking de variables más influyentes — se espera que converjan con la literatura (SpO₂, frecuencia respiratoria, temperatura) para reforzar la validez de constructo del modelo, tal como reportan Lee et al. 2022.
- Traducir al menos 2-3 ejemplos de predicción individual a lenguaje clínico comprensible (ej. "el modelo asignó Nivel II principalmente por saturación de O₂ baja (88%) y frecuencia respiratoria elevada") — esto es insumo directo para argumentar la adopción clínica en el Cap. 5.

## Fase 6 — Consolidación y documentación

- `Cap4.md`: metodología real ejecutada (no la planeada) — variables finales usadas, arquitectura ganadora con justificación, hiperparámetros clave.
- `README.md`: cómo reproducir el pipeline completo desde cero (para que la comisión evaluadora, si lo pide, pueda verificar).
- `artifacts/` final: modelos serializados + `metrics/` con el desglose por clase en CSV, listo para insertar como tabla en el Cap. 5.
