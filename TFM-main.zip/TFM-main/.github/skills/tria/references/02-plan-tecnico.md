# Plan técnico — Stack, artefactos y cronograma

> Fuente: `technical-plan.md`. Consulta este documento antes de proponer librerías, estructura de carpetas o fechas distintas a las ya acordadas.

## Stack fijado

- **Lenguaje:** Python 3.10+ (preferible 3.11).
- **Gestión de entorno:** `poetry` recomendado (alternativa: `venv` + `requirements.txt`).
- **Datos tabulares:** `pandas`, `numpy`, `scikit-learn`, `imbalanced-learn` (para desbalance de clases).
- **Boosting:** `xgboost`.
- **NLP/embeddings de texto clínico:** `transformers`, `sentence-transformers` — priorizar modelo clínico en español si existe uno disponible (evaluar BioBERT-es o similar antes de usar un BERT genérico en inglés).
- **Deep learning (si aplica):** preferir `torch` sobre `tensorflow`, especialmente si se entrena/afina un BERT.
- **Explicabilidad:** `shap`.
- **Utilidades:** `joblib`, `pyyaml`, `tqdm`.
- **Notebooks:** `jupyterlab`, `nbformat`.
- **Repositorio:** Git, con `.gitignore` y `pyproject.toml` (o `requirements.txt`).
- **Contenerización:** `Dockerfile` opcional, solo si se busca reproducibilidad extra.

## Requisitos de cómputo

- Desarrollo local: CPU multicore (≥4 núcleos), 16 GB RAM — suficiente para XGBoost y modelos clásicos.
- Entrenamiento de BERT: GPU ≥8GB VRAM (ej. RTX 3060) o alternativa cloud (Colab Pro). Si no hay GPU disponible, usar embeddings **precomputados** en vez de fine-tuning completo — es la mitigación oficial del riesgo de recursos limitados.
- Almacenamiento estimado: 10-50 GB dependiendo del dataset final.

## Estructura de artefactos (no reinventar)

```
notebooks/
├── 01-data-ingest-and-eda.ipynb
├── 02-preprocessing.ipynb
├── 03-baseline-models.ipynb
├── 04-multimodal-training.ipynb
└── 05-evaluation-and-shap.ipynb
src/
├── preprocess.py
├── train.py
├── evaluate.py
└── embeddings.py
artifacts/
├── model_xgb.joblib
├── bert_model/
├── metrics/          # CSV con métricas por clase
└── reports/           # PDF o Markdown con tablas y figuras
data/
└── README.md          # esquema de datasets y scripts de ingest
Cap4.md                 # borrador de Capítulo 4
README.md
deployment-notes.md      # opcional, solo como nota de trabajo futuro (fuera de alcance real)
```

Si el usuario pide crear un archivo nuevo, verifica primero si encaja en esta estructura antes de proponer una carpeta distinta.

## Cronograma (6 semanas, equipo de 3 personas)

| Semana | Foco | Entrega |
|---|---|---|
| 1 | Datos y EDA — descargar/organizar CSV/Parquet, EDA por dataset y esquema de features | `notebooks/01-data-ingest-and-eda.ipynb` |
| 2 | Preprocesamiento y pipeline — limpieza, imputación, normalización, tokenización, splits reproducibles | `notebooks/02-preprocessing.ipynb`, `src/preprocess.py` |
| 3 | Modelos baseline — Regresión Logística, RF, XGBoost sobre estructurado; métricas por clase, manejo de desbalance | `notebooks/03-baseline-models.ipynb`, artefactos iniciales |
| 4 | Multimodal — embeddings de texto, fusión early y late, entrenamiento | `notebooks/04-multimodal-training.ipynb`, `src/embeddings.py` |
| 5 | Evaluación y XAI — métricas por clase (recall objetivo), AUPRC/AUROC, SHAP + ejemplos clínicos traducidos | `notebooks/05-evaluation-and-shap.ipynb`, `reports/` |
| 6 | Consolidación — pulir notebooks, redactar borrador Cap. 4, empaquetar artefactos reproducibles | `Cap4.md`, `README.md`, `artifacts/` final |

Total: 6 semanas calendario (≈18 persona-semanas si los 3 integrantes trabajan coordinados a tiempo completo — ajustar si hay menos disponibilidad real, que es lo más probable dado que es un TFM part-time).

## Hitos y criterios de aceptación por hito

- **Hito 1** (fin semana 2): pipelines de ingest y preprocesamiento reproducibles.
- **Hito 2** (fin semana 3): modelos baseline con métricas iniciales.
- **Hito 3** (fin semana 4): multimodal entrenado y comparado (early vs. late).
- **Hito 4** (fin semana 5): cumplimiento de criterios por clase **o documentación explícita de por qué no se alcanzan** — esto último es válido y esperado si ocurre, no lo ocultes ni lo fuerces.
- **Hito 5** (fin semana 6): entregables finales y borrador Cap. 4/5.

## Riesgos y mitigaciones (ya acordados, no los replantees desde cero)

| Riesgo | Mitigación |
|---|---|
| Acceso a datos hospitalarios bloqueado por ética | Trabajar con MIMIC-IV-ED + datasets públicos; documentar la limitación explícitamente en el TFM, no simularla ni omitirla. |
| Clases altamente desbalanceadas (I-II son minoritarias pero críticas) | Class weights, resampling (SMOTE), métricas por clase; priorizar recall en I-II. |
| Recursos GPU limitados | Embeddings precomputados o servicios cloud (Colab/OCI/GCP/Azure). |

## Próximos pasos inmediatos (según el plan original)

1. Confirmar acceso y ubicación real de los CSV/Parquet entre los 3 integrantes.
2. Crear repositorio/estructura de carpetas + `pyproject.toml` o `requirements.txt`.
3. Asignar tareas semanales entre los integrantes (Diego, Erick, Leyniker).
