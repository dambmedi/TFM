# Requisitos funcionales — Triaje Multimodal IA (cerrado, IA=19/100)

> Fuente: `001-triaje-multimodal-ia-urgencias.md`, resultado del protocolo de clarificación (2 rondas, IA 48→19). Este documento es la especificación de referencia; no se debe re-derivar desde cero en cada sesión.

## Necesidad de negocio

Sistema **offline** de apoyo a la decisión clínica que, a partir de datos estructurados y texto libre de admisión, clasifica pacientes de urgencias en los 5 niveles de la Resolución 5596 de 2015 (I-V) y da explicabilidad (SHAP) para respaldar —no reemplazar— la decisión humana durante el triaje.

## Actores

| Rol | Tipo | Responsabilidad |
|---|---|---|
| Equipo TFM (Diego Medina, Erick Soto, Leyniker Rivera) | Ejecutor | Preparar datos, entrenar modelos, documentar, entregar notebooks/artefactos |
| Directora — Damaris Fuentes Lorenzo | Aprobador / beneficiario académico | Validar criterios de aceptación y revisar entregables para defensa |
| Comité de Ética (Hospital San Juan de Dios) | Bloqueador / validador | Autorizar uso de datos locales y validar anonimización |
| TI del hospital (si aplica) | Consultor | Aclarar formatos de datos si se requiere |

## Alcance

**Dentro de alcance:**
- Desarrollo offline del modelo multimodal (estructurado + texto).
- Preprocesamiento completo del pipeline de datos.
- Experimentos comparativos: fusión temprana (early fusion) vs. tardía (late fusion).
- Evaluación desagregada por clase (no solo métricas agregadas).
- Notebooks reproducibles.
- Módulo de explicabilidad con SHAP.

**Fuera de alcance (explícito, no ambiguo):**
- Integración en HCE/EHR en tiempo real.
- Interfaz web o móvil.
- Procesamiento de imágenes médicas.
- Certificación regulatoria (INVIMA).
- Despliegue en producción.

## Criterios de aceptación

**Metas agregadas (piso general):**
- F1 (macro) ≥ 0,82
- Precisión (macro) ≥ 0,85
- Recall (macro) ≥ 0,80
- AUC-ROC (macro) ≥ 0,87

**Metas por clase (obligatorias — este es el criterio real de éxito, no el agregado):**
- Nivel I: Recall ≥ 0,90
- Nivel II: Recall ≥ 0,85
- Nivel III: Recall ≥ 0,80
- Nivel IV: Recall ≥ 0,75
- Nivel V: Recall ≥ 0,75

Ejemplos formales (Gherkin, tal como quedaron en el requisito cerrado):

```
DADO un conjunto de validación etiquetado con niveles I–V
CUANDO se evalúa el modelo final
ENTONCES el Recall para Nivel I será ≥ 0.90
```

```
DADO un conjunto de validación etiquetado
CUANDO se calcula F1 macro
ENTONCES F1_macro será ≥ 0.82
```

> Nota de estado: estas metas por clase son una **propuesta técnica del equipo**, pendiente de validación formal por Damaris (ver Ronda 2 de clarificación). Trátalas como criterio de trabajo válido, pero si el usuario menciona que ya fueron aprobadas o modificadas por la directora, actualiza este documento.

## Restricciones y supuestos

**Restricciones:**
- Datos del Hospital San Juan de Dios sujetos a autorización ética — solo se usan datos anonimizados y autorizados. Estado: **en trámite**, no confirmado.
- MIMIC-IV-ED requiere credenciales CITI (PhysioNet); solo se usa cuando el investigador que la posea la gestione. Adaptar a Colombia requiere fine-tuning con datos locales.

**Supuestos validados:**
- El equipo TFM provee los CSV/Parquet (descargas propias, no se sube nada a repositorios externos por terceros).
- Las descargas públicas (Min. Salud, BDUA, Supersalud) están disponibles sin restricción adicional.

**Supuestos no validados (pendientes):**
- Umbrales operativos definitivos de alerta para Niveles I-II — la directora debe confirmar tolerancia real a falsas alarmas en contexto hospitalario.
- Tamaño real del dataset por clase — desconocido hasta ejecutar el EDA inicial (Fase 1 del plan técnico). No asumir cifras sin haber corrido `01-data-ingest-and-eda.ipynb`.

## Prioridad (MoSCoW)

- **Must have:** modelos entrenados offline, evaluación por clase, notebooks reproducibles, documentación de preprocesamiento, explicabilidad SHAP.
- **Should have:** comparativa early vs. late fusion, análisis de técnicas para desbalance de clases (class weights, SMOTE, focal loss).
- **Could have:** script de reportes automáticos con tabla de métricas por clase, notebook con visualizaciones interactivas.
- **Won't have:** interfaz web, integración EHR, procesamiento de imágenes, certificación regulatoria.

## Brechas pendientes (a la fecha de cierre del requisito)

| Campo | Falta | Impacto |
|---|---|---|
| Validación ética | Estado final de la autorización del Comité de Ética | Bloqueante para entrenar/afinar con datos hospitalarios reales. Mientras no se resuelva, trabajar solo con MIMIC + datos públicos y documentar la limitación explícitamente en el TFM. |
| Sample anonimizado | CSV de muestra para pruebas de preprocesado local | Necesario para tests replicables en contexto colombiano — pendiente de entrega por el equipo. |

## Entregables del MVP

- Repositorio con notebooks reproducibles (preprocesamiento, baseline, multimodal early/late, evaluación, SHAP).
- Artefactos de modelos (pesos/serialización) + scripts de evaluación por clase.
- Documento técnico: Cap. 4 (metodología) y Cap. 5 (resultados y discusión) del TFM.
