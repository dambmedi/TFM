# Restricciones éticas y manejo de datos sensibles

> Este documento existe porque el Art. 2.7 del Reglamento de TFG/TFM de UNIR es explícito y bloqueante: *"Si el trabajo se realiza sin dicha autorización [del Comité de Ética], no se permitirá su depósito ni su defensa."* Cualquier trabajo con datos del Hospital San Juan de Dios debe pasar por este filtro antes de ejecutarse, no después.

## Estado actual del trámite (a la fecha de creación de esta skill)

**No confirmado — en trámite.** Ninguno de los documentos del proyecto (requisitos, plan técnico, contexto del TFM) reporta una autorización ya obtenida. Trata este estado como el default hasta que el usuario confirme explícitamente lo contrario en una sesión — y si lo confirma, actualiza este archivo.

## Qué se puede usar sin restricción adicional

| Fuente | Motivo |
|---|---|
| MIMIC-IV-ED (PhysioNet) | Dataset público, ya anonimizado, acceso reglado vía credencial CITI del propio investigador — no requiere trámite adicional del Comité de Ética de UNIR. |
| CSV "Clasificación en Triaje Urgencias" (datos.gov.co) | Dato abierto agregado del Min. Salud. |
| BDUA (ADRES) | Dato abierto agregado. |
| Datos abiertos Supersalud | Dato abierto agregado, nivel EPS/IPS, no de pacientes individuales. |

## Qué NO se puede usar hasta tener autorización explícita

- Registro clínico del Hospital San Juan de Dios (datos sanitarios de personas identificables o potencialmente reidentificables).
- Cualquier sample o extracto de ese registro, por pequeño que sea (la pregunta de "¿nos pueden dar un CSV de 1-2k filas para pruebas?" quedó explícitamente sin resolver en la Ronda 2 de clarificación — no asumas que un sample pequeño está exento del mismo requisito).

## Qué hacer si el usuario pide trabajar con los datos del hospital

1. Preguntar directamente si ya se confirmó la autorización del Comité de Ética — no lo des por hecho ni lo bloquees de forma pasivo-agresiva, simplemente confirma.
2. Si no está confirmada, ofrece la alternativa ya acordada como mitigación oficial (ver plan técnico): avanzar todo el pipeline con MIMIC-IV-ED + datos públicos, dejando el punto de integración del registro hospitalario como un paso claramente marcado y condicionado en el código (ej. una celda de notebook con un comentario explícito `# BLOQUEADO: requiere autorización Comité de Ética — ver references/04-restricciones-eticas.md`).
3. Sugiere documentar esto como limitación explícita en el Cap. 6 del TFM si para el momento de redactar conclusiones el trámite sigue sin resolverse — es una limitación legítima y defendible ante el tribunal, no algo que ocultar.

## Anonimización (Ley 1581 de 2012, Colombia)

No existe todavía un procedimiento de anonimización aprobado — ninguno de los tres actores relevantes (equipo TFM, Damaris, Comité de Ética del hospital) lo ha definido formalmente. Esto significa dos cosas para cualquier trabajo futuro:

1. **No hay un script de anonimización "estándar" que aplicar** — si el usuario pide escribir uno, es correcto proponerlo, pero debe quedar explícito que es una **propuesta del equipo pendiente de validación**, no un procedimiento ya aceptado.
2. **Candidato natural de entregable:** este procedimiento (documentado, con su justificación técnica y legal) encaja bien en los Apéndices del TFM, que hoy están vacíos.

**Elementos mínimos que debería cubrir la propuesta cuando se escriba:**
- Eliminación o seudonimización de identificadores directos (nombre, documento de identidad, dirección).
- Generalización de cuasi-identificadores (ej. edad en rangos en vez de fecha de nacimiento exacta, si el volumen de datos hace que la edad exacta + otras variables permita reidentificación).
- Separación de las notas de texto libre de cualquier identificador antes de generar embeddings (el texto clínico narrativo es el campo con mayor riesgo de contener nombres o datos identificables "colados" por el personal que lo redactó).
- Registro de quién tuvo acceso a los datos crudos antes de la anonimización y por cuánto tiempo (trazabilidad mínima).

## Validadores designados

- **Damaris Fuentes Lorenzo** (directora del TFM) — validación académica del procedimiento de anonimización y del cumplimiento general.
- **Comité de Ética de la Investigación de UNIR** — autorización formal exigida por el Art. 2.7 del Reglamento, previa a cualquier recogida/uso de datos del hospital.
- Posible validación adicional del propio comité de ética/habeas data del Hospital San Juan de Dios, si su protocolo interno lo exige — pendiente de confirmar, no asumir que no aplica.
