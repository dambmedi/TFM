---
name: triaje-multimodal-tfm
description: >-
  Guía y ejecuta el desarrollo técnico del TFM "Sistema de triaje multimodal basado en IA
  para urgencias médicas en Colombia" (UNIR, equipo Medina/Rivera/Soto, directora Damaris
  Fuentes Lorenzo). Úsala SIEMPRE que el usuario trabaje en cualquier parte del pipeline de
  este proyecto específico, incluyendo ingesta o EDA de MIMIC-IV-ED / CSV de Min. Salud /
  BDUA / Supersalud, preprocesamiento de datos clínicos, entrenamiento de modelos baseline
  (Regresión Logística, Random Forest, XGBoost) o multimodales (fusión temprana/tardía con
  embeddings de texto clínico), evaluación por clase con métricas de recall/F1/AUC-ROC,
  explicabilidad con SHAP, o redacción de los Capítulos 4 y 5 del TFM. Dispara también con
  frases como "sigamos con el TFM del triaje", "notebook de preprocesamiento", "entrena el
  modelo multimodal", "calcula el SHAP", "escribe el Cap4", aunque el usuario no mencione
  explícitamente "triaje" o "IA" en ese mensaje puntual, siempre que el contexto de la
  conversación sea este proyecto.
---

# TFM — Sistema de Triaje Multimodal basado en IA (Colombia)

Esta skill encapsula el contrato de trabajo ya cerrado para este TFM (Índice de Ambigüedad final: 19/100 — ver `references/01-requisitos-funcionales.md`) y el plan técnico de ejecución (`references/02-plan-tecnico.md`). No vuelvas a re-negociar alcance, métricas o restricciones ya definidas ahí salvo que el usuario lo pida explícitamente — esa fase de clarificación ya se cerró. Tu trabajo aquí es **ejecutar**, no volver a preguntar.

## Por qué existe esta skill

Este es un proyecto largo, con muchas sesiones de trabajo separadas en el tiempo (EDA → preprocesamiento → baseline → multimodal → evaluación → redacción). Sin este contexto persistente, cada sesión nueva corre el riesgo de: (a) reinterpretar el alcance desde cero, (b) proponer arquitecturas o librerías distintas a las ya acordadas, o (c) ignorar restricciones éticas/normativas que son bloqueantes reales para la defensa del TFM (Art. 2.7 del Reglamento UNIR: sin autorización del Comité de Ética sobre los datos del Hospital San Juan de Dios, el trabajo no puede depositarse ni defenderse). Esta skill fija ese contexto para que cualquier sesión futura parta del mismo punto.

## Antes de escribir código o texto: ubica la fase

El proyecto avanza en 6 fases secuenciales (detalladas en `references/02-plan-tecnico.md`). Identifica en qué fase está el usuario según lo que pide, y ve directo al artefacto correspondiente — no reinicies desde la Fase 1 salvo que el usuario lo pida:

| Si el usuario pide... | Fase | Artefacto principal |
|---|---|---|
| Descargar/explorar datos, EDA | 1 | `notebooks/01-data-ingest-and-eda.ipynb` |
| Limpieza, imputación, normalización, tokenización | 2 | `notebooks/02-preprocessing.ipynb`, `src/preprocess.py` |
| Regresión Logística / RF / XGBoost sobre datos estructurados | 3 | `notebooks/03-baseline-models.ipynb` |
| Embeddings de texto, fusión early/late | 4 | `notebooks/04-multimodal-training.ipynb`, `src/embeddings.py` |
| Métricas por clase, SHAP | 5 | `notebooks/05-evaluation-and-shap.ipynb`, `reports/` |
| Redactar Cap.4/Cap.5, consolidar | 6 | `Cap4.md`, `README.md`, `artifacts/` |

Si es la primera vez que se toca el repositorio en la sesión, verifica primero si ya existe la estructura de carpetas (`notebooks/`, `src/`, `artifacts/`, `data/`) antes de crearla — no la sobrescribas.

## Reglas no negociables (ya cerradas en la clarificación)

Estas ya no están sujetas a debate — vienen directo del documento de requisitos cerrado. Si el usuario propone algo que las contradice, señálalo explícitamente en vez de aplicarlo en silencio:

1. **Alcance:** solo modelo entrenado y evaluado offline (notebooks + artefactos). Nada de interfaz web, API, integración EHR/HCE en tiempo real, procesamiento de imágenes médicas, ni certificación regulatoria (INVIMA). Ver "Out of scope" en `references/01-requisitos-funcionales.md`.
2. **Prioridad de optimización:** recall alto en Niveles I-II (falsos negativos ahí son el peor error posible clínicamente), balance en III-V. No optimices solo el F1/accuracy agregado sin reportar el desglose por clase.
3. **Metas mínimas por clase** (criterio de aceptación, no aspiracional): Recall Nivel I ≥ 0,90; Nivel II ≥ 0,85; Nivel III ≥ 0,80; Nivel IV-V ≥ 0,75. Metas agregadas: F1 ≥ 0,82, Precisión ≥ 0,85, Recall ≥ 0,80, AUC-ROC ≥ 0,87. Si un modelo no las alcanza, no lo presentes como "listo" — repórtalo como gap documentado (así lo exige el Hito 4 del plan técnico).
4. **Bloqueo ético activo:** los datos del Hospital San Juan de Dios NO se usan hasta que el usuario confirme autorización explícita del Comité de Ética. Mientras tanto, trabaja solo con MIMIC-IV-ED y los tres CSV públicos (Min. Salud, BDUA, Supersalud). Si el usuario pide procesar datos del hospital sin haber confirmado la autorización, pregunta primero — no asumas que ya se resolvió.
5. **Anonimización:** cualquier script que toque datos con identificadores de terceros debe aplicar un procedimiento de anonimización documentado (Ley 1581 de 2012, Colombia) — ver `references/04-restricciones-eticas.md`. Este procedimiento aún no existe y debe proponerse como parte del entregable (candidato natural para los Apéndices del TFM), no darse por hecho.
6. **Stack fijado:** Python 3.10+/3.11, `pandas`/`scikit-learn`/`imbalanced-learn` para tabular, `xgboost` para boosting, `transformers`/`sentence-transformers` para texto clínico, `shap` para explicabilidad, `torch` como preferencia sobre `tensorflow` si se entrena un BERT. No cambies de stack sin que el usuario lo pida — ver `references/02-plan-tecnico.md` para el detalle completo y alternativas de cómputo (CPU vs GPU vs Colab).

## Flujo de trabajo por tipo de tarea

### Si piden código de un notebook/script de una fase
1. Consulta `references/03-pipeline-tecnico.md` para el detalle técnico de esa fase específica (columnas esperadas, técnicas de imputación, cómo estructurar la fusión early/late, cómo calcular SHAP sobre el modelo ganador).
2. Escribe el código respetando la estructura de carpetas ya fijada (`notebooks/`, `src/`, `artifacts/`, `data/`) — no inventes una estructura distinta.
3. Si el paso involucra datos reales del hospital, aplica la Regla 4 (verificar autorización) antes de escribir el código de ingesta.
4. Todo modelo entrenado debe evaluarse con el desglose por clase de la Regla 3, no solo con métricas agregadas.

### Si piden avanzar/replanificar el cronograma
Consulta `references/02-plan-tecnico.md` (cronograma de 6 semanas, hitos y criterios de aceptación por hito) antes de proponer fechas o reordenar tareas. Si el usuario reporta que van atrasados respecto al cronograma de UNIR (`programacion.pdf` del TFM, no incluido en esta skill), ayuda a priorizar qué Fase del plan técnico es más urgente dado el calendario académico real, no solo el ideal de 6 semanas.

### Si piden redactar el Cap. 4 o Cap. 5 del TFM
1. El Cap. 4 (Desarrollo de la contribución) debe reflejar exactamente lo ejecutado en Fases 1-4: selección de variables, arquitectura de fusión elegida (con justificación early vs. late basada en métricas reales, no supuestas), y proceso de entrenamiento.
2. El Cap. 5 (Resultados y discusión) debe reportar el desglose de métricas por clase de la Regla 3, comparar contra los benchmarks de la literatura ya citados en el estado del arte del TFM (CTAS AUROC 0.882, Ueareekul et al. AUROC 0.917, etc.), y ser honesto sobre qué metas no se alcanzaron y por qué.
3. No redactes resultados que el usuario no te haya dado — si no ha corrido los experimentos todavía, ofrece la estructura/esqueleto del capítulo con placeholders claros, no números inventados.

### Si piden resolver una duda de alcance/requisito nueva
Antes de responder desde cero, revisa `references/01-requisitos-funcionales.md` — es posible que ya esté resuelta ahí. Si es genuinamente nueva (no cubierta en el documento de requisitos cerrado), trátala como lo haría el protocolo de clarificación: pregunta en vez de asumir, y sugiere al usuario si conviene documentarla como adenda al requisito 001 para que quede trazada.

## Índice de referencias

- `references/01-requisitos-funcionales.md` — Especificación funcional cerrada (alcance, actores, criterios de aceptación, restricciones, prioridad MoSCoW). Fuente de verdad para "qué" se construye.
- `references/02-plan-tecnico.md` — Stack, estructura de artefactos, cronograma de 6 semanas con hitos, riesgos y mitigaciones. Fuente de verdad para "cómo" y "cuándo".
- `references/03-pipeline-tecnico.md` — Detalle técnico fase por fase (variables esperadas, técnicas de preprocesamiento, arquitectura de fusión, cálculo de SHAP). Consulta esto antes de escribir código de cualquier fase.
- `references/04-restricciones-eticas.md` — Reglas de manejo de datos sensibles, estado del trámite ético, y qué hacer mientras esté pendiente.
